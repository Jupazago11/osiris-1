<script>console.log("Entra consultarnoti");</script>
<?php 
    require_once("../php/funciones.php"); 
    ver_notificaciones();
?>