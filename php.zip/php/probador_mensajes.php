<script>
    alert("<?php echo $_POST['Nufactura'] ?>");
</script>