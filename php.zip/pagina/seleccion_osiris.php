<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title class="w3-center w3-animate-top">Inicio de Sesión</title>
    <script type="text/javascript" src="../JavaScript/funciones.js"></script>
    <LINK REL=StyleSheet HREF="../CSS/estilos.css">
</head>
<body>
<div class="seleccion">
    <form name="btn_osiris1" action="sesion_manzana.php" method='post'>
        <input type="submit" class="btn btn-primary btn-block btn-large" value="Osiris Manzana" id="enviar">
    </form>
    <br>
    <form name="btn_osiris2" action="sesion_tropical.php" method='post'>
        <input type="submit" class="btn btn-primary btn-block btn-large" value="Osiris Tropical" id="enviar">
    </form>
</div>
</body>
</html>